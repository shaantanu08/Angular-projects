import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-secondcomp',
  templateUrl: './secondcomp.component.html',
  styleUrls: ['./secondcomp.component.css']
})
export class SecondcompComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
