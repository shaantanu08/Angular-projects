import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<div style="text-align:center">
  <h1>
    Welcome to {{ title }}!
  </h1>
  
  <label>Marvellous Infosystem : </label>
  <input type="text" placeholder="Enter text" name="">
  </div>`,

  styles: [`label{
    color: blue;
    font-size: 0.8cm;
  }
  input{
    block-size: 0.8cm;
  }`,]
})
export class AppComponent {
  title = 'ThiredProject';
}
